open Scanf
open Printf

let create_transicoes i c j list = 
    [(i,c,j)]@list

let rec insert3 num list = 
    if num = 0 then
        list
    else
        let i = scanf " %d" (fun a -> a) in
        let c = scanf " %c" (fun a -> a) in
        let j = scanf " %d" (fun a -> a) in
        let list = create_transicoes i c j list in
        insert3 (num-1) list

let rec existC listaC a =
  match listaC with
  | [] -> 1
  | h::tl ->  if h = a then
                0
              else
                existC tl a
      
      
let rec caracteres listaT listaC =
  match listaT with
  | [] -> listaC
  | (i,c,j)::tl ->  if (existC listaC c) = 1 then
                      let listaC = [c]@listaC in
                      caracteres tl listaC
                    else
                      caracteres tl listaC

      
let create_finais pos list = 
  match list with
  | [] -> [pos]
  | h::t -> [pos]@list

                                
let rec insert2 num list = 
  if num = 0 then 
    list
  else
    let pos = scanf " %d" (fun a -> a) in
    let list = create_finais pos list in
    insert2 (num-1) list



let n = scanf " %d" (fun a -> a) 

let so = scanf " %d" (fun a -> a)

let sf = scanf " %d" (fun a -> a)

let listaF = []

let listaF = insert2 sf listaF 

let tr = scanf " %d" (fun a -> a)
        
let listaT = [] 
        
let listaT = insert3 tr listaT 
        
let listaC = []

let listaC = caracteres listaT listaC

let tabela = Array.make_matrix (n+1) (n+1) (-1)



let rec prontaARAux tabela j i n =
if j < i then
  let () = tabela.(i).(j) <- 0 in
  prontaARAux tabela (j+1) i n 
else
  prontaAR tabela (i+1) n  

and prontaAR tabela i n =
  if i < n then
    prontaARAux tabela 1 i n
  else
    ()


  let rec exist a list =
    match list with
    | [] -> 0
    | h::tl ->  if a = h then 
                    1
                else
                    exist a tl


let rec estadosFAux tabela j i n listaF=
  if j < i then
    if (exist i listaF) <> (exist j listaF) then
      let () = tabela.(i).(j) <- 1 in
      estadosFAux tabela (j+1) i n listaF
    else
      estadosFAux tabela (j+1) i n listaF
  else
    estadosF tabela (i+1) n listaF 
                    
and estadosF tabela i n listaF =
  if i < n then
    estadosFAux tabela 1 i n listaF
  else
    ()


let rec where a cr listaT =
    match listaT with
    | [] -> -1
    | (i,c,j)::tl ->if (a = i) && (cr = c) then
                        j
                    else
                        where a cr tl


let rec enquanto chave n listaT tabela listaC = 
  if chave = 1 then
    marcar 0 n listaT tabela listaC listaC 0
  else
    ()

and marcar i n listaT tabela listaC save chave =
  if i < n then
    marcarAux 1 i n listaT tabela listaC save chave 
  else
    ()

and marcarAux j i n listaT tabela listaC save chave = 
  if j < i then
    match listaC with
    | [] -> if chave = 0 then
              marcarAux (j+1) i n listaT tabela save save 0
            else
              marcarAux (j+1) i n listaT tabela save save 1 
    | c::tl ->  let fj = where j c listaT in
                let fi = where i c listaT in
                if tabela.(fi).(fj) = 1 || tabela.(fj).(fi) = 1 then
                  let () = tabela.(i).(j) <- 1 in
                  marcarAux j i n listaT tabela tl save 1
                else
                  if chave = 0 then
                    marcarAux j i n listaT tabela tl save 0
                  else
                    marcarAux j i n listaT tabela tl save 1 
  else
    marcar (i+1) n listaT tabela listaC save chave 


let rec mostrar list = 
  match list with
  | [] -> printf "\n"
  | (x,y)::tl ->  let () = printf "(%d,%d)" x y in 
              mostrar tl



let () = prontaAR tabela 1 (n+1)

let () = estadosF tabela 1 (n+1) listaF 

let () = enquanto 1 (n+1) listaT tabela listaC

let listaP = []



let insertP listaP po =
  match listaP with 
  | [] -> [po]
  | (x,y)::tl ->  listaP@[po]


  let rec tratarPOAux j i n tabela lista=
  if j = i then
    lista
  else
    if tabela.(i).(j) = 0 then
      let lista = insertP lista (j,i) in
      tratarPOAux (j+1) i n tabela lista
    else
      tratarPOAux (j+1) i n tabela lista

and tratarPO i n tabela lista = 
if i = n then
lista
else
  let lista = tratarPOAux 1 i n tabela lista in
  tratarPO (i+1) n tabela lista


let rec remove listaP (c,d) list=
  match listaP with
  | [] -> list
  | (a,b)::tl -> if a = c && b = d then
                remove tl (c,d) list
                else
                remove tl (c,d) list@[(a,b)]

let rec simplificaPaux listaP tail lista (a,b) key= 
  match listaP with
  | [] -> if key = 0 then (lista@[(a,b)],tail) else (lista,tail)  
  | (c,d)::tl ->  if b = c then
                  let lista = lista@[(a,d)] in
                  let tl = remove tl (c,d) [] in
                  let tail = remove tail (c,d) [] in
                  simplificaPaux tl tail lista (a,b) 1
                  else
                  simplificaPaux tl tail lista (a,b) key
                  

let rec simplificaP listaP lF =
  match listaP with
    | [] -> lF
    | (a,b)::tl ->  let (lF,tl) = simplificaPaux tl tl lF (a,b) 0 in
                    simplificaP tl lF            


let rec exist2 (a,b) list =
  match list with
  | [] -> 0
  | (c,d)::tl ->  if a = c && b = d then 
                  1
              else
                  exist2 (a,b) tl

let rec elRep listaP return =
  match listaP with
  | [] -> return
  | (a,b)::tl ->  if (exist2 (a,b) tl) = 1 then
                    elRep tl return
                  else
                  let return = return@[(a,b)] in
                    elRep tl return



let listaP = tratarPO 1 (n+1) tabela listaP

let listaP = simplificaP listaP []

let listaP = elRep listaP []

let () = mostrar listaP     

     
