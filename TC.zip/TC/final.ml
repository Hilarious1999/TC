open Scanf
open Printf

let create_transicoes i c j list = 
    [(i,c,j)]@list

let rec insert3 num list = 
    if num = 0 then
        list
    else
        let i = scanf " %d" (fun a -> a) in
        let c = scanf " %c" (fun a -> a) in
        let j = scanf " %d" (fun a -> a) in
        let list = create_transicoes i c j list in
        insert3 (num-1) list

let rec existC listaC a =
  match listaC with
  | [] -> 1
  | h::tl ->  if h = a then
                0
              else
                existC tl a
      
      
      
let rec caracteres listaT listaC =
  match listaT with
  | [] -> listaC
  | (i,c,j)::tl ->  if (existC listaC c) = 1 then
                      let listaC = [c]@listaC in
                      caracteres tl listaC
                    else
                      caracteres tl listaC
      
let create_finais pos list = 
  match list with
  | [] -> [pos]
  | h::t -> [pos]@list
                                
let rec insert2 num list = 
  if num = 0 then 
    list
  else
    let pos = scanf " %d" (fun a -> a) in
    let list = create_finais pos list in
    insert2 (num-1) list

let n = scanf " %d" (fun a -> a) 

let so = scanf " %d" (fun a -> a)

let sf = scanf " %d" (fun a -> a)

let listaF = []

let listaF = insert2 sf listaF 

let tr = scanf " %d" (fun a -> a) 
        
let listaT = [] 
        
let listaT = insert3 tr listaT 
        
let listaC = []

let listaC = caracteres listaT listaC

let tabela = Array.make_matrix (n+1) (n+1) (-1)



let rec mostrarARAux tabela j i n =
  if j < i then
    let () = printf "(%d %d %d)  " i j tabela.(i).(j) in
    mostrarARAux tabela (j+1) i n 
  else
    mostrarAR tabela (i+1) n  

and mostrarAR tabela i n =
  if i < n then
    let () = printf "\n" in
    mostrarARAux tabela 1 i n
  else
  ()



  let rec prontaARAux tabela j i n =
if j < i then
  let () = tabela.(i).(j) <- 0 in
  prontaARAux tabela (j+1) i n 
else
  prontaAR tabela (i+1) n  

and prontaAR tabela i n =
  if i < n then
    prontaARAux tabela 1 i n
  else
    ()


    
let rec exist a list =
  match list with
  | [] -> 0
  | h::tl ->  if a = h then 
                1
              else
                exist a tl



let rec estadosFAux tabela j i n listaF=
  if j < i then
    if (exist i listaF) <> (exist j listaF) then
      let () = tabela.(i).(j) <- 1 in
      estadosFAux tabela (j+1) i n listaF
    else
      estadosFAux tabela (j+1) i n listaF
  else
    estadosF tabela (i+1) n listaF 
                    
and estadosF tabela i n listaF =
  if i < n then
    estadosFAux tabela 1 i n listaF
  else
    ()



let rec where a cr listaT =
    match listaT with
    | [] -> -1
    | (i,c,j)::tl ->if (a = i) && (cr = c) then
                        j
                    else
                        where a cr tl



let rec enquanto chave n listaT tabela listaC = 
  let () = mostrarAR tabela 1 (n+1) in
  let () = printf "\n" in
  if chave = 1 then
    marcar 0 n listaT tabela listaC listaC 0
  else
    ()

and marcar i n listaT tabela listaC save chave =
  if i < n then
    marcarAux 1 i n listaT tabela listaC save chave 
  else
    ()

and marcarAux j i n listaT tabela listaC save chave = 
  if j < i then
    match listaC with
    | [] -> if chave = 0 then
              marcarAux (j+1) i n listaT tabela save save 0
            else
              marcarAux (j+1) i n listaT tabela save save 1 
    | c::tl ->  let fj = where j c listaT in
                let fi = where i c listaT in
                if tabela.(fi).(fj) = 1 || tabela.(fj).(fi) = 1 then
                  let () = tabela.(i).(j) <- 1 in
                  marcarAux j i n listaT tabela tl save 1
                else
                  if chave = 0 then
                    marcarAux j i n listaT tabela tl save 0
                  else
                    marcarAux j i n listaT tabela tl save 1 
  else
    marcar (i+1) n listaT tabela listaC save chave 



let rec mostrar list = 
  match list with
  | [] -> printf "\n"
  | x::tl ->  let () = printf "%d " x in 
              mostrar tl


let rec mostrar2 list = 
  match list with
  | [] -> printf "\n"
  | x::tl ->  let () = printf "%d" x in 
              mostrar2 tl              


let insertP listaP po =
  match listaP with 
  | [] -> [po]
  | (x,y)::tl ->  listaP@[po]

  let rec tratarPOAux j i n tabela lista=
  if j = i then
    lista
  else
    if tabela.(i).(j) = 0 then
      let lista = insertP lista (j,i) in
      tratarPOAux (j+1) i n tabela lista
    else
      tratarPOAux (j+1) i n tabela lista

and tratarPO i n tabela lista = 
if i = n then
lista
else
  let lista = tratarPOAux 1 i n tabela lista in
  tratarPO (i+1) n tabela lista



let rec remove listaP (c,d) list=
  match listaP with
  | [] -> list
  | (a,b)::tl -> if a = c && b = d then
                remove tl (c,d) list
                else
                remove tl (c,d) list@[(a,b)]



let rec simplificaPaux listaP tail lista (a,b) key= 
  match listaP with
  | [] -> if key = 0 then (lista@[(a,b)],tail) else (lista,tail)  
  | (c,d)::tl ->  if b = c then
                  let lista = lista@[(a,d)] in
                  let tl = remove tl (c,d) [] in
                  let tail = remove tail (c,d) [] in
                  simplificaPaux tl tail lista (a,b) 1
                  else
                  simplificaPaux tl tail lista (a,b) key
                  


let rec simplificaP listaP lF =
  match listaP with
    | [] -> lF
    | (a,b)::tl ->  let (lF,tl) = simplificaPaux tl tl lF (a,b) 0 in
                    simplificaP tl lF            



let rec exist2 (a,b) list =
  match list with
  | [] -> 0
  | (c,d)::tl ->  if a = c && b = d then 
                  1
              else
                  exist2 (a,b) tl



let rec elRep listaP return =
  match listaP with
  | [] -> return
  | (a,b)::tl ->  if (exist2 (a,b) tl) = 1 then
                    elRep tl return
                  else
                  let return = return@[(a,b)] in
                    elRep tl return



let rec findN lista =
  match lista with
  | [] -> 0
  | (a,b)::tl -> (b-a) + findN tl 



let rec exist3 lista c =
  match lista with
  | [] -> (-1,-1)
  | (a,b)::tl ->  if a = c || b = c then
                    (a,b)
                  else
                    exist3 tl c



let rec countTR tR = 
  match tR with
  | [] -> 0
  | h::tl -> 1 + countTR tl



let rec mostrar2 list = 
  match list with
  | [] -> printf ""
  | (a,c,b)::tl ->  let () = printf "%d %c %d\n" a c b in 
                    mostrar2 tl



let rec mostrar3 list = 
  match list with
  | [] -> printf "\n"
  | (a,b)::tl ->  let () = printf "(%d,%d)" a b in 
                    mostrar3 tl

  
let rec remover (a,c,b) lista listaf =
  match lista with
  | [] -> listaf
  | (d,e,f)::tl ->  if a = d && c = e && b = f then
                      remover (a,c,b) tl listaf
                    else
                      let listaf = listaf@[(d,e,f)] in
                      remover (a,c,b) tl listaf


  
let rec limpar lista listaf =
  match lista with 
  | [] -> listaf
  | (a,c,b)::tl ->  let tl = remover (a,c,b) tl [] in
                    let listaf = listaf@[(a,c,b)] in
                    limpar tl listaf



let rec remover2 a lista listaf =
  match lista with
  | [] -> listaf
  | b::tl ->  if a = b then
                remover2 a tl listaf
              else
                let listaf = listaf@[b] in
                remover2 a tl listaf
    
  

let rec limpar2 lista listaf =
   match lista with
   | [] -> listaf
   | a::tl -> let tl = remover2 a tl [] in
              let listaf = listaf@[a] in
              limpar2 tl listaf
  

  
let rec exist3 lista c =
  match lista with
  | [] -> (-1,-1)
  | (a,b)::tl ->  if a = c || b = c then
                    (a,b)
                  else
                    exist3 tl c
  


let rec madeConv lista (a,b) n =
  if a <= b then
    let lista = lista@[(a,n)] in
    madeConv lista ((a+1),b) n
  else
    lista


      
let rec conv a lista =
  match lista with
  | [] -> -1
  | (b,c)::tl -> if a = b then c else conv a tl


  
let rec transUp listaT lista listaTF =
  match listaT with
  | [] -> listaTF
  | (a,c,b)::tl ->  let af = conv a lista in
                    let bf = conv b lista in
                    let listaTF = [(af,c,bf)]@listaTF in
                    transUp tl lista listaTF
  


let rec final listaP listaT listaE i n at =
  if i < n then
    let (a,b) = (exist3 listaP i) in
    if (a,b) = (-1,-1) then
      let listaE = madeConv listaE (i,i) (i-at) in
      final listaP listaT listaE (i+1) n at
    else
      let listaE = madeConv listaE (a,b) (i-at) in 
      let at = (at + (b-a)) in
      final listaP listaT listaE (b+1) n at
  else
    listaE



let rec find lista so =
  match lista with
  | [] -> -1
  | (a,b)::tl -> if so = a then b else find tl so

let rec findSF lista listaF listan=
  match listaF with
  | [] -> listan
  | h::tl ->  let add = find lista h in
              let listan = listan@[add] in
              findSF lista tl listan


let () = prontaAR tabela 1 (n+1)

let () = estadosF tabela 1 (n+1) listaF

let () = enquanto 1 (n+1) listaT tabela listaC                

(*  let () = mostrarAR tabela 1 (n+1)
let () = printf "\n" 
*)
let listaP = []
      
let listaP = tratarPO 1 (n+1) tabela listaP

let () = mostrar3 listaP

let listaP = simplificaP listaP []  

let () = mostrar3 listaP

let listaP = elRep listaP [] 

let () = mostrar3 listaP

let nn = n - (findN listaP)

let () = printf"%d\n" nn

let listaFinal = final listaP listaT [] 1 7 0

let () = printf"%d\n" (find listaFinal so)

let nFF = findSF listaFinal listaF []

let nFF = limpar2 nFF [] 

let () = printf"%d\n" (countTR nFF)

let () = mostrar nFF

let listaTF = transUp listaT listaFinal []

let listaTF = limpar listaTF []

let ntr = countTR listaTF

let () = printf "%d\n" ntr

let () = mostrar2 listaTF