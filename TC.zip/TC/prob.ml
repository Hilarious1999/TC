open Scanf
open Printf

(*******FUNCOES MOSTRAR TABELAS*******)

let rec mostrarARAux tabela j i n =
  if j < i then
    let () = printf "(%d %d %d)  " i j tabela.(i).(j) in
    mostrarARAux tabela (j+1) i n 
  else
    mostrarAR tabela (i+1) n  

and mostrarAR tabela i n =
  if i < n then
    let () = printf "\n" in
    mostrarARAux tabela 1 i n
  else
  ()

(*******FUNCOES MOSTRAR LISTAS*******)
let rec mostrarN list = 
  match list with
  | [] -> printf "\n"
  | x::[] ->  let () = printf "%d" x in 
              mostrarN []
  | x::tl ->  let () = printf "%d " x in 
              mostrarN tl
  

let rec mostrarLL listalist =
  match listalist with
  | [] -> printf"\n"
  | lista::tl ->  let () = mostrarN lista in
                  mostrarLL tl

let rec mostrarC list = 
  match list with
  | [] -> printf "\n"
  | x::tl ->  let () = printf "%c " x in 
              mostrarC tl

let rec mostrar2 list = 
  match list with
  | [] -> printf "\n"
  | (a,b)::tl ->  let () = printf "(%d,%d)" a b in 
              mostrar2 tl              

let rec mostrarT list = 
  match list with
  | [] -> printf ""
  | (a,c,b)::tl ->  let () = printf "%d %c %d\n" a c b in 
                    mostrarT tl


(*******FUNCOES DE LEITURA DE DADOS*******)

let create_transicoes i c j list = 
    list@[(i,c,j)]

let rec insert3 num list = 
    if num = 0 then
        list
    else
        let i = scanf " %d" (fun a -> a) in
        let c = scanf " %c" (fun a -> a) in
        let j = scanf " %d" (fun a -> a) in
        let list = create_transicoes i c j list in
        insert3 (num-1) list

let rec existC listaC a =
  match listaC with
  | [] -> 1
  | h::tl ->  if h = a then
                0
              else
                existC tl a
      
      
      
let rec caracteres listaT listaC =
  match listaT with
  | [] -> listaC
  | (i,c,j)::tl ->  if (existC listaC c) = 1 then
                      let listaC = listaC@[c] in
                      caracteres tl listaC
                    else
                      caracteres tl listaC
      
let create_finais pos list = 
  match list with
  | [] -> [pos]
  | h::t -> list@[pos]
                                
let rec insert2 num list = 
  if num = 0 then 
    list
  else
    let pos = scanf " %d" (fun a -> a) in
    let list = create_finais pos list in
    insert2 (num-1) list

(**************)


(*******LEITURA DE DADOS*******)

let n = scanf " %d" (fun a -> a) 

let so = scanf " %d" (fun a -> a)

let sf = scanf " %d" (fun a -> a)

let listaF = []

let listaF = insert2 sf listaF 

let tr = scanf " %d" (fun a -> a) 
        
let listaT = [] 
        
let listaT = insert3 tr listaT 
        
let listaC = []

let listaC = caracteres listaT listaC

let tabela = Array.make_matrix (n+1) (n+1) (-1)

(*******TESTE LEITURA DE DADOS*******)

(*
let () = printf "%d\n" n
let () = printf "%d\n" so
let () = printf "%d\n" sf
let () = mostrarN listaF 
let () = printf "%d\n" tr
let () = mostrarT listaT
let () = mostrarC listaC 
*)

(*******FUNCOES COLOCAR A TABELA READY*******)

let rec prontaARAux tabela j i n =
  if j < i then
    let () = tabela.(i).(j) <- 0 in
    prontaARAux tabela (j+1) i n 
  else
    prontaAR tabela (i+1) n  

and prontaAR tabela i n =
  if i < n then
    prontaARAux tabela 1 i n
  else
    ()


    
let rec exist a list =
  match list with
  | [] -> 0
  | h::tl ->  if a = h then 
                1
              else
                exist a tl



let rec estadosFAux tabela j i n listaF=
  if j < i then
    if (exist i listaF) <> (exist j listaF) then
      let () = tabela.(i).(j) <- 1 in
      estadosFAux tabela (j+1) i n listaF
    else
      estadosFAux tabela (j+1) i n listaF
  else
    estadosF tabela (i+1) n listaF 
                    
and estadosF tabela i n listaF =
  if i < n then
    estadosFAux tabela 1 i n listaF
  else
    ()

let rec where a cr listaT =
  match listaT with
  | [] -> -1
  | (i,c,j)::tl ->if (a = i) && (cr = c) then
                      j
                  else
                      where a cr tl


let rec enquanto chave n listaT tabela listaC = 
  (*let () = printf "\n Enquanto A CHAVE É %d\n" chave in
  let () = mostrarAR tabela 1 n in*)
  (*let () = printf "\n" in*)
  if chave = 1 then
    marcar 1 n listaT tabela listaC listaC 0
  else
    tabela

and marcar i n listaT tabela listaC save chave =

  if i < n then
  (*let () = printf "\n MARCAR A CHAVE É %d\n" chave in*)
    marcarAux 1 i n listaT tabela listaC save chave 
  else
    enquanto chave n listaT tabela listaC

and marcarAux j i n listaT tabela listaC save chave = 
  if j < i then
  (*let () = printf "\n MARCARAUX A CHAVE É %d --> (%d,%d)\n" chave i j in*)
    match listaC with
    | [] -> marcarAux (j+1) i n listaT tabela save save chave 
    | c::tl ->  (*let () = printf " \t\t\t%c\n" c in*)
                let fj = where j c listaT in
                let fi = where i c listaT in
                if (tabela.(fi).(fj) = 1 || tabela.(fj).(fi) = 1) && tabela.(i).(j) = 0 then
                  let () = tabela.(i).(j) <- 1 in
                  marcarAux j i n listaT tabela tl save 1
                else
                  marcarAux j i n listaT tabela tl save chave 
  else
    marcar (i+1) n listaT tabela listaC save chave

(*******COLOCAR A TABELA READY*******)

let () = prontaAR tabela 1 (n+1)
(* let () = mostrarAR tabela 1 (n+1) *)
let () = estadosF tabela 1 (n+1) listaF
(* let () = mostrarAR tabela 1 (n+1) *)
let tabela = enquanto 1 (n+1) listaT tabela listaC
(*let () = mostrarAR tabela 1 (n+1) *)

(*******FUNÇOES PARA CRIAR LISTA DE ESTADOS SIMILARES*******)

let insertP listaP po =
  match listaP with 
  | [] -> [po]
  | (x,y)::tl ->  listaP@[po]

  let rec tratarPOAux j i n tabela lista=
  if j = i then
    lista
  else
    if tabela.(i).(j) = 0 then
      let lista = insertP lista (j,i) in
      tratarPOAux (j+1) i n tabela lista
    else
      tratarPOAux (j+1) i n tabela lista

and tratarPO i n tabela lista = 
if i = n then
lista
else
  let lista = tratarPOAux 1 i n tabela lista in
  tratarPO (i+1) n tabela lista


let rec existL a lista = 
  match lista with 
  | [] -> 0
  | b::tl ->  if a = b then
                1
              else
                existL a tl 


let rec tratar3 (a,b) lista return mud=
  match lista with
  | [] -> (return,mud)
  | h::tl ->  if h = a then
                if (existL b return) = 1 then
                  tratar3 (a,b) tl return 1
                else
                  let return = return@[b] in
                  tratar3 (a,b) tl return 1
              else
                if h = b then
                  if (existL a return) = 1 then
                    tratar3 (a,b) tl return 1
                  else
                    let return = return@[a] in
                    tratar3 (a,b) tl return 1
                else
                  tratar3 (a,b) tl return mud


let rec tratar2 (a,b) listalist return mud=
  match listalist with
  | [] -> if mud = 0 then let return = return@[[a]@[b]] in return else return
  | lista::tl -> let (lista,mud) = tratar3 (a,b) lista lista 0 in
                 let return = return@[lista] in
                 tratar2 (a,b) tl return mud


let rec tratar listaP return =
  match listaP with
  | [] -> return
  | (a,b)::tl ->  (*let () = printf "OLA (%d %d)\n" a b in*)
                  let return = tratar2 (a,b) return [] 0 in
                  (*let () = mostrarLL return in*)
                  tratar tl return   
                  



(*******CRIAÇAO DA LISTA DE ESTADOS SIMILARES*******)

let listaP = []
      
let listaP = tratarPO 1 (n+1) tabela listaP

(*let () = mostrar2 listaP*)

let listaPfinal = tratar listaP []

(*let () = mostrarLL listaPfinal *)

(*******FUNCOES PARA GERAR LISTA COM VALOR DOS ESTADOS ANTIGOS E OS NOVOS*******)
let rec madeListEs i n return =
  if i < n then let return = return@[i] in madeListEs (i+1) n return else return

let rec remove lista a return =
  match lista with
  | [] -> return
  | x::tl ->  if x = a then
                remove tl a return
              else
                let return = return@[x] in
                remove tl a return

let rec conv lista return nw tail=
  match lista with
  | [] -> (return,tail)
  | a::tl ->  let return = return@[(a,nw)] in
              let tail = remove tail a [] in
              conv tl return nw tail

let rec find i nw listalist listaConv tail mud=
  match listalist with
  | [] -> if mud = 1 then 
            (listaConv,tail) 
          else
            let listaConv = listaConv@[(i,nw)] in
            (*let () = printf "CONVERSOES\n" in
            let () = mostrar2 listaConv in*)
            (listaConv,tail)
  | lista::tl ->  if (existL i lista) = 1 then
                    let (conversoes,tail) = conv lista [] nw tail in
                    let listaConv = listaConv@conversoes in
                    (*let () = printf "CONVERSOES\n" in
                    let () = mostrar2 listaConv in*)
                    find i nw tl listaConv tail 1
                  else
                    find i nw tl listaConv tail mud

let rec criar es return listaList nw =
  match es with
  | [] -> return
  | h::tl ->  let (aux,tl) = find h nw listaList return tl 0 in
              (*let () = printf "ESTADOS QUE FALTAM\n"in*)
              (*let () = mostrarN tl in*)
              let return = aux in
              criar tl return listaList (nw+1)

(*******CRIAR LISTA COM VALOR DOS ESTADOS ANTIGOS E OS NOVOS*******)

(*let () = printf "------------------\n"*)
let listaEstados = madeListEs 1 (n+1) []
(*let () = mostrarN listaEstados *)
let listaConv = criar listaEstados [] listaPfinal 1
(*let () = mostrar2 listaConv*)


(*******FUNCOES FINAIS*******)

let rec findN listaConv n =
  match listaConv with
  | [] -> n
  | (a,b)::tl -> findN tl b

let rec find lista so =
  match lista with
  | [] -> -1
  | (a,b)::tl -> if so = a then b else find tl so

let rec findSF lista listaF listan=
  match listaF with
  | [] -> listan
  | h::tl ->  let add = find lista h in
              let listan = listan@[add] in
              findSF lista tl listan
  
let rec count tR = 
  match tR with
  | [] -> 0
  | h::tl -> 1 + count tl

  let rec remover (a,c,b) lista listaf =
  match lista with
  | [] -> listaf
  | (d,e,f)::tl ->  if a = d && c = e && b = f then
                      remover (a,c,b) tl listaf
                    else
                      let listaf = listaf@[(d,e,f)] in
                      remover (a,c,b) tl listaf


  
let rec limpar lista listaf =
  match lista with 
  | [] -> listaf
  | (a,c,b)::tl ->  let tl = remover (a,c,b) tl [] in
                    let listaf = listaf@[(a,c,b)] in
                    limpar tl listaf



let rec remover2 a lista listaf =
  match lista with
  | [] -> listaf
  | b::tl ->  if a = b then
                remover2 a tl listaf
              else
                let listaf = listaf@[b] in
                remover2 a tl listaf
    
  

let rec limpar2 lista listaf =
   match lista with
   | [] -> listaf
   | a::tl -> let tl = remover2 a tl [] in
              let listaf = listaf@[a] in
              limpar2 tl listaf

          
let rec conv a lista =
  match lista with
  | [] -> -1
  | (b,c)::tl -> if a = b then c else conv a tl


  
let rec transUp listaT lista listaTF =
  match listaT with
  | [] -> listaTF
  | (a,c,b)::tl ->  let af = conv a lista in
                    let bf = conv b lista in
                    let listaTF = listaTF@[(af,c,bf)] in
                    transUp tl lista listaTF
                    
                    
(*******FINAL*******)


let nN = findN listaConv (-1)

let () = printf "%d\n" nN

let nSO = find listaConv so

let () = printf "%d\n" nSO

let nLSF = findSF listaConv listaF []

let nLSF = limpar2 nLSF []

let nSF = count nLSF

let () = printf "%d\n" nSF

let () = mostrarN nLSF

let nLTR = transUp listaT listaConv []

let nLTR = limpar nLTR []

let nTR = count nLTR

let () = printf "%d\n" nTR

let () = mostrarT nLTR